"use client";

import { useCallback, useEffect, useMemo, useState } from "react";

const STATUS_OPTIONS = [
  "all",
  "applied",
  "interviewing",
  "offered",
  "rejected",
  "withdrawn",
];

const STATUS_STYLES = {
  applied: "bg-amber-50 text-amber-700 border-amber-200",
  interviewing: "bg-purple-50 text-purple-700 border-purple-200",
  offered: "bg-emerald-50 text-emerald-700 border-emerald-200",
  rejected: "bg-red-50 text-red-700 border-red-200",
  withdrawn: "bg-gray-100 text-gray-600 border-gray-200",
};

function formatDate(date) {
  if (!date) return "Not available";

  return new Date(date).toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function formatStatus(status) {
  if (!status) return "Unknown";

  return status.charAt(0).toUpperCase() + status.slice(1);
}

function getInitials(name = "") {
  return name
    .split(" ")
    .filter(Boolean)
    .map((part) => part[0])
    .slice(0, 2)
    .join("")
    .toUpperCase() || "S";
}

function StatusBadge({ status }) {
  return (
    <span
      className={`inline-flex items-center px-3 py-1.5 rounded-full border text-xs font-semibold ${
        STATUS_STYLES[status] ||
        "bg-gray-100 text-gray-600 border-gray-200"
      }`}
    >
      {formatStatus(status)}
    </span>
  );
}

function StatCard({ label, value, description }) {
  return (
    <div className="rounded-2xl border border-border bg-surface p-5">
      <p className="text-xs font-medium text-text-muted">{label}</p>
      <p className="font-display text-2xl font-bold text-text mt-2">
        {value ?? 0}
      </p>
      {description && (
        <p className="text-xs text-text-muted mt-1">{description}</p>
      )}
    </div>
  );
}

function EmptyState({ title, description }) {
  return (
    <div className="py-16 px-5 text-center">
      <div className="w-14 h-14 rounded-2xl bg-rose-soft text-primary flex items-center justify-center mx-auto mb-4">
        <svg
          viewBox="0 0 24 24"
          className="w-7 h-7"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.7"
        >
          <path
            d="M8 7h8M8 11h8M8 15h5M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Z"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>
      <h3 className="font-display font-bold text-text">{title}</h3>
      <p className="text-sm text-text-muted mt-2 max-w-md mx-auto">
        {description}
      </p>
    </div>
  );
}

function ApplicationCard({
  application,
  onStatusChange,
  onDownloadCV,
  updatingId,
  downloadingId,
}) {
  const student =
    application.studentId ||
    application.userId ||
    application.student ||
    {};

  const internship =
    application.internshipId ||
    application.internship ||
    {};

  const cv = application.cvId || application.cv || {};

  const studentName =
    student.fullName ||
    student.name ||
    student.profile?.fullName ||
    "Student";

  const email = student.email || "No email available";

  const internshipTitle =
    internship.title ||
    internship.position ||
    "Internship";

  const isUpdating = updatingId === application._id;
  const isDownloading = downloadingId === application._id;

  return (
    <article className="rounded-2xl border border-border bg-surface overflow-hidden">
      <div className="p-5 sm:p-6">
        <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-5">
          <div className="flex items-start gap-4 min-w-0">
            <div className="w-12 h-12 shrink-0 rounded-full bg-rose-soft text-primary flex items-center justify-center font-bold text-sm">
              {getInitials(studentName)}
            </div>

            <div className="min-w-0">
              <h3 className="font-display font-bold text-text text-base">
                {studentName}
              </h3>
              <p className="text-xs text-text-muted mt-1 break-all">
                {email}
              </p>
              <p className="text-sm font-semibold text-text-secondary mt-3">
                {internshipTitle}
              </p>
              <p className="text-xs text-text-muted mt-1">
                Applied on {formatDate(application.appliedAt || application.createdAt)}
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center gap-3">
            <StatusBadge status={application.status} />

            <button
              type="button"
              onClick={() => onDownloadCV(application)}
              disabled={isDownloading || !application.cvId}
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-border text-text text-xs font-semibold hover:bg-background transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isDownloading ? (
                "Preparing..."
              ) : (
                <>
                  <svg
                    viewBox="0 0 24 24"
                    className="w-4 h-4"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.8"
                  >
                    <path
                      d="M12 3v12m0 0 5-5m-5 5-5-5M5 17v3h14v-3"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                  Download CV
                </>
              )}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-6 pt-5 border-t border-border">
          <div>
            <p className="text-[11px] uppercase tracking-wide text-text-muted font-semibold">
              CV
            </p>
            <p className="text-sm text-text mt-1 break-all">
              {cv.file?.originalName ||
                cv.originalName ||
                application.cvSnapshot?.originalName ||
                "No CV information"}
            </p>
          </div>

          <div>
            <p className="text-[11px] uppercase tracking-wide text-text-muted font-semibold">
              Application method
            </p>
            <p className="text-sm text-text mt-1">
              {application.applicationMethod === "external"
                ? "External application"
                : "InternCheck application"}
            </p>
          </div>

          <div>
            <p className="text-[11px] uppercase tracking-wide text-text-muted font-semibold">
              Last updated
            </p>
            <p className="text-sm text-text mt-1">
              {formatDate(application.updatedAt || application.appliedAt)}
            </p>
          </div>
        </div>

        {application.notes && (
          <div className="mt-5 rounded-xl bg-background p-4">
            <p className="text-[11px] uppercase tracking-wide text-text-muted font-semibold">
              Student note
            </p>
            <p className="text-sm text-text-secondary mt-2 whitespace-pre-wrap">
              {application.notes}
            </p>
          </div>
        )}
      </div>

      <div className="px-5 sm:px-6 py-4 bg-background border-t border-border flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <p className="text-xs text-text-muted">
          Update the application status as the recruitment process progresses.
        </p>

        <select
          value={application.status || "applied"}
          onChange={(event) =>
            onStatusChange(application._id, event.target.value)
          }
          disabled={isUpdating}
          className="px-4 py-2.5 rounded-xl bg-surface border border-border text-xs font-semibold text-text focus:outline-none focus:ring-2 focus:ring-primary/20 disabled:opacity-50"
        >
          {STATUS_OPTIONS.filter((status) => status !== "all").map((status) => (
            <option key={status} value={status}>
              {formatStatus(status)}
            </option>
          ))}
        </select>
      </div>
    </article>
  );
}

export default function RecruiterApplicationsPage() {
  const [applications, setApplications] = useState([]);
  const [stats, setStats] = useState({});
  const [pagination, setPagination] = useState({
    page: 1,
    totalPages: 1,
    total: 0,
  });

  const [status, setStatus] = useState("all");
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [updatingId, setUpdatingId] = useState(null);
  const [downloadingId, setDownloadingId] = useState(null);

  const loadApplications = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const query = new URLSearchParams({
        page: String(page),
        limit: "10",
      });

      if (status !== "all") query.set("status", status);
      if (search.trim()) query.set("search", search.trim());

      const response = await fetch(
        `/api/recruiter/applications?${query.toString()}`,
        {
          credentials: "include",
          cache: "no-store",
        }
      );

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(
          result.message || "Unable to load applications."
        );
      }

      setApplications(result.data || []);
      setStats(result.stats || {});
      setPagination(
        result.pagination || {
          page: 1,
          totalPages: 1,
          total: result.data?.length || 0,
        }
      );
    } catch (err) {
      setError(err.message || "Unable to load applications.");
    } finally {
      setLoading(false);
    }
  }, [page, status, search]);

  useEffect(() => {
    loadApplications();
  }, [loadApplications]);

  async function handleStatusChange(applicationId, newStatus) {
    setUpdatingId(applicationId);
    setError("");
    setSuccess("");

    try {
      const response = await fetch(
        `/api/recruiter/applications/${applicationId}`,
        {
          method: "PATCH",
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ status: newStatus }),
        }
      );

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(
          result.message || "Unable to update application status."
        );
      }

      setApplications((previous) =>
        previous.map((application) =>
          application._id === applicationId
            ? {
                ...application,
                ...(result.data || {}),
                status: newStatus,
              }
            : application
        )
      );

      setSuccess("Application status updated successfully.");
      await loadApplications();
    } catch (err) {
      setError(err.message || "Unable to update application status.");
    } finally {
      setUpdatingId(null);
    }
  }

  async function handleDownloadCV(application) {
    setDownloadingId(application._id);
    setError("");
    setSuccess("");

    try {
      const response = await fetch(
        `/api/recruiter/applications/${application._id}/cv`,
        {
          method: "GET",
          credentials: "include",
          redirect: "follow",
        }
      );

      if (!response.ok) {
        let message = "Unable to download this CV.";

        try {
          const result = await response.json();
          message = result.message || message;
        } catch {
          // Response may not be JSON.
        }

        throw new Error(message);
      }

      const blob = await response.blob();

      if (!blob.size) {
        throw new Error("The downloaded CV is empty.");
      }

      const disposition = response.headers.get("content-disposition");
      const filenameMatch = disposition?.match(
        /filename\*?=(?:UTF-8''|")?([^";]+)/i
      );

      const filename = filenameMatch
        ? decodeURIComponent(filenameMatch[1].replaceAll('"', ""))
        : application.cvId?.file?.originalName ||
          application.cvId?.originalName ||
          application.cvSnapshot?.originalName ||
          "candidate-cv";

      const objectUrl = window.URL.createObjectURL(blob);
      const link = document.createElement("a");

      link.href = objectUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      link.remove();

      window.URL.revokeObjectURL(objectUrl);

      setSuccess("CV downloaded successfully.");
    } catch (err) {
      setError(err.message || "Unable to download this CV.");
    } finally {
      setDownloadingId(null);
    }
  }

  const totalApplications = pagination.total ?? applications.length;

  const filteredDescription = useMemo(() => {
    if (status === "all") return "All applications";
    return `${formatStatus(status)} applications`;
  }, [status]);

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-10">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-text">
            Applications
          </h1>
          <p className="text-sm text-text-muted mt-1">
            Review candidates and manage your internship applications.
          </p>
        </div>

        <button
          type="button"
          onClick={loadApplications}
          disabled={loading}
          className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl border border-border bg-surface text-text text-sm font-semibold hover:bg-background transition-colors disabled:opacity-50"
        >
          <svg
            viewBox="0 0 24 24"
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.8"
          >
            <path
              d="M20 7v5h-5M4 17v-5h5M5.5 9a7 7 0 0 1 12-2L20 12M4 12l2.5 5a7 7 0 0 0 12-2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          Refresh
        </button>
      </div>

      {error && (
        <div className="rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">
          {error}
        </div>
      )}

      {success && (
        <div className="rounded-xl bg-emerald-50 border border-emerald-200 px-4 py-3 text-sm text-emerald-700">
          {success}
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <StatCard
          label="Total Applications"
          value={stats.total ?? totalApplications}
          description="Applications received"
        />
        <StatCard
          label="Applied"
          value={stats.applied}
          description="Awaiting review"
        />
        <StatCard
          label="Interviewing"
          value={stats.interviewing}
          description="In the interview process"
        />
        <StatCard
          label="Offered"
          value={stats.offered}
          description="Offers extended"
        />
      </div>

      <section className="rounded-2xl border border-border bg-surface p-5">
        <div className="flex flex-col lg:flex-row lg:items-end gap-4">
          <label className="flex-1 space-y-2">
            <span className="text-xs font-semibold text-text-secondary">
              Search candidates
            </span>
            <div className="relative">
              <svg
                viewBox="0 0 24 24"
                className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
              >
                <circle cx="10.8" cy="10.8" r="6.8" />
                <path
                  d="m16 16 4.5 4.5"
                  strokeLinecap="round"
                />
              </svg>
              <input
                type="search"
                value={search}
                onChange={(event) => {
                  setSearch(event.target.value);
                  setPage(1);
                }}
                placeholder="Search by student name or email..."
                className="w-full pl-11 pr-4 py-3 rounded-xl bg-background border border-border text-sm text-text placeholder:text-text-muted focus:outline-none focus:ring-2 focus:ring-primary/20"
              />
            </div>
          </label>

          <label className="w-full lg:w-56 space-y-2">
            <span className="text-xs font-semibold text-text-secondary">
              Application status
            </span>
            <select
              value={status}
              onChange={(event) => {
                setStatus(event.target.value);
                setPage(1);
              }}
              className="w-full px-4 py-3 rounded-xl bg-background border border-border text-sm text-text focus:outline-none focus:ring-2 focus:ring-primary/20"
            >
              {STATUS_OPTIONS.map((option) => (
                <option key={option} value={option}>
                  {option === "all" ? "All statuses" : formatStatus(option)}
                </option>
              ))}
            </select>
          </label>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mt-5 pt-4 border-t border-border">
          <p className="text-xs text-text-muted">
            Showing {filteredDescription.toLowerCase()}
          </p>
          <p className="text-xs text-text-muted">
            {totalApplications} application(s)
          </p>
        </div>
      </section>

      <section className="space-y-4">
        {loading ? (
          <div className="rounded-2xl border border-border bg-surface py-16 text-center">
            <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-sm text-text-muted mt-4">
              Loading applications...
            </p>
          </div>
        ) : applications.length === 0 ? (
          <div className="rounded-2xl border border-border bg-surface">
            <EmptyState
              title="No applications found"
              description={
                search || status !== "all"
                  ? "Try changing your search or status filter."
                  : "Applications submitted for your internships will appear here."
              }
            />
          </div>
        ) : (
          applications.map((application) => (
            <ApplicationCard
              key={application._id}
              application={application}
              onStatusChange={handleStatusChange}
              onDownloadCV={handleDownloadCV}
              updatingId={updatingId}
              downloadingId={downloadingId}
            />
          ))
        )}
      </section>

      {!loading && pagination.totalPages > 1 && (
        <div className="flex items-center justify-center gap-3">
          <button
            type="button"
            disabled={page <= 1}
            onClick={() => setPage((previous) => Math.max(1, previous - 1))}
            className="px-4 py-2.5 rounded-xl border border-border text-sm font-semibold text-text disabled:opacity-40 disabled:cursor-not-allowed hover:bg-background"
          >
            Previous
          </button>

          <span className="text-xs text-text-muted">
            Page {pagination.page || page} of {pagination.totalPages}
          </span>

          <button
            type="button"
            disabled={page >= pagination.totalPages}
            onClick={() =>
              setPage((previous) =>
                Math.min(pagination.totalPages, previous + 1)
              )
            }
            className="px-4 py-2.5 rounded-xl border border-border text-sm font-semibold text-text disabled:opacity-40 disabled:cursor-not-allowed hover:bg-background"
          >
            Next
          </button>
        </div>
      )}
    </div>
  );
}