
"use client";

import { useMemo, useState } from "react";

// --------------------------------------------------
// Mock feedback data
// --------------------------------------------------

const initialFeedback = [
  {
    id: "FDB-001",
    student: "Aarav Sharma",
    university: "Lovely Professional University",
    internship: "Frontend Developer Intern",
    department: "Engineering",
    rating: 5,
    category: "Positive",
    submittedAt: "Nov 12, 2026",
    experience:
      "The internship provided an excellent learning environment. I worked with React and modern frontend technologies, received regular guidance from the development team, and got to contribute to real-world features.",
    highlights: [
      "Supportive mentors",
      "Real-world projects",
      "Good learning environment",
    ],
    improvements:
      "More frequent technical workshops would make the experience even better.",
    status: "Published",
  },
  {
    id: "FDB-002",
    student: "Priya Verma",
    university: "Chandigarh University",
    internship: "UI/UX Design Intern",
    department: "Design",
    rating: 4,
    category: "Positive",
    submittedAt: "Nov 10, 2026",
    experience:
      "I learned a lot about user research, prototyping and design systems. The team was approachable and encouraged creative thinking.",
    highlights: [
      "Creative freedom",
      "Helpful design team",
      "Practical experience",
    ],
    improvements:
      "The onboarding process could be more structured.",
    status: "Published",
  },
  {
    id: "FDB-003",
    student: "Rohan Mehta",
    university: "Thapar Institute of Engineering",
    internship: "Backend Developer Intern",
    department: "Engineering",
    rating: 3,
    category: "Neutral",
    submittedAt: "Nov 08, 2026",
    experience:
      "The technical work was interesting and helped me understand backend development better. However, project requirements were sometimes unclear.",
    highlights: [
      "Interesting technical work",
      "Exposure to APIs",
    ],
    improvements:
      "Clearer task documentation and more consistent mentor interaction would improve the experience.",
    status: "Published",
  },
  {
    id: "FDB-004",
    student: "Simran Kaur",
    university: "Delhi University",
    internship: "Data Analyst Intern",
    department: "Analytics",
    rating: 5,
    category: "Positive",
    submittedAt: "Nov 06, 2026",
    experience:
      "A wonderful experience working with real datasets and learning industry tools. The team was very supportive throughout the internship.",
    highlights: [
      "Hands-on data projects",
      "Excellent mentorship",
      "Industry exposure",
    ],
    improvements:
      "No major improvements needed.",
    status: "Published",
  },
  {
    id: "FDB-005",
    student: "Kabir Singh",
    university: "Lovely Professional University",
    internship: "Frontend Developer Intern",
    department: "Engineering",
    rating: 2,
    category: "Negative",
    submittedAt: "Nov 04, 2026",
    experience:
      "The internship did not fully match my expectations. Most tasks were repetitive, and I did not receive enough guidance when I faced technical problems.",
    highlights: [
      "Basic exposure to frontend development",
    ],
    improvements:
      "Provide structured tasks, regular feedback and more meaningful project responsibilities.",
    status: "Published",
  },
  {
    id: "FDB-006",
    student: "Neha Gupta",
    university: "Punjab Engineering College",
    internship: "Backend Developer Intern",
    department: "Engineering",
    rating: 4,
    category: "Positive",
    submittedAt: "Nov 02, 2026",
    experience:
      "The internship helped me improve my Java and database skills. I especially appreciated the opportunity to work on an actual application.",
    highlights: [
      "Practical development experience",
      "Good technical exposure",
      "Collaborative team",
    ],
    improvements:
      "More code review sessions would be beneficial.",
    status: "Published",
  },
];

const filters = [
  "All",
  "Positive",
  "Neutral",
  "Negative",
];

const categoryStyles = {
  Positive: "bg-success/10 text-success border-success/20",
  Neutral: "bg-warning/10 text-warning border-warning/20",
  Negative: "bg-danger/10 text-danger border-danger/20",
};

// --------------------------------------------------
// Reusable components
// --------------------------------------------------

function StarRating({ rating, size = "normal" }) {
  return (
    <div className="inline-flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((star) => (
        <svg
          key={star}
          className={`${
            size === "large" ? "w-5 h-5" : "w-3.5 h-3.5"
          } ${
            star <= rating
              ? "text-amber-400"
              : "text-text-muted/25"
          }`}
          fill="currentColor"
          viewBox="0 0 20 20"
        >
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.96a1 1 0 00.95.69h4.165c.969 0 1.371 1.24.588 1.81l-3.37 2.449a1 1 0 00-.364 1.118l1.287 3.96c.3.922-.755 1.688-1.539 1.119l-3.37-2.449a1 1 0 00-1.176 0l-3.37 2.449c-.783.569-1.838-.197-1.539-1.118l1.287-3.96a1 1 0 00-.364-1.118L2.122 9.387c-.783-.57-.38-1.81.588-1.81h4.165a1 1 0 00.95-.69l1.224-3.96z" />
        </svg>
      ))}
    </div>
  );
}

function CategoryBadge({ category }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[11px] font-bold font-ui ${
        categoryStyles[category]
      }`}
    >
      <span className="w-1.5 h-1.5 rounded-full bg-current" />
      {category}
    </span>
  );
}

function Avatar({ name }) {
  const initials = name
    .split(" ")
    .map((part) => part[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  return (
    <div className="w-10 h-10 shrink-0 rounded-full bg-rose-soft text-primary flex items-center justify-center font-ui text-xs font-bold">
      {initials}
    </div>
  );
}

function StatCard({ label, value, description, icon, accent }) {
  return (
    <div className="bg-surface border border-border rounded-[var(--radius-lg)] p-4 sm:p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="font-ui text-xs text-text-secondary font-medium">
            {label}
          </p>

          <h3 className="font-display text-2xl font-bold text-text mt-2">
            {value}
          </h3>

          <p className="font-ui text-[11px] text-text-muted mt-1">
            {description}
          </p>
        </div>

        <div
          className={`w-10 h-10 rounded-xl flex items-center justify-center ${accent}`}
        >
          {icon}
        </div>
      </div>
    </div>
  );
}

function EmptyState({ searchQuery }) {
  return (
    <div className="bg-surface border border-border rounded-[var(--radius-lg)] py-14 px-5 text-center">
      <div className="mx-auto w-12 h-12 rounded-full bg-surface-alt flex items-center justify-center text-text-muted mb-3">
        <svg
          className="w-6 h-6"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          strokeWidth={1.8}
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M11.05 3.055a9 9 0 1010.395 10.395M12 7v5l3 2m4-11v4m-2-2h4"
          />
        </svg>
      </div>

      <h3 className="font-ui text-sm font-bold text-text">
        No feedback found
      </h3>

      <p className="font-ui text-xs text-text-muted mt-1">
        {searchQuery
          ? "Try changing your search or selected filter."
          : "Student feedback will appear here."}
      </p>
    </div>
  );
}

// --------------------------------------------------
// Main page
// --------------------------------------------------

export default function RecruiterFeedbackPage() {
  const [feedback, setFeedback] = useState(initialFeedback);
  const [activeFilter, setActiveFilter] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedFeedback, setSelectedFeedback] = useState(null);

  // ------------------------------------------------
  // Statistics
  // ------------------------------------------------

  const stats = useMemo(() => {
    const total = feedback.length;

    const average =
      total > 0
        ? feedback.reduce((sum, item) => sum + item.rating, 0) /
          total
        : 0;

    return {
      total,
      average: average.toFixed(1),
      positive: feedback.filter(
        (item) => item.category === "Positive"
      ).length,
      negative: feedback.filter(
        (item) => item.category === "Negative"
      ).length,
    };
  }, [feedback]);

  // ------------------------------------------------
  // Filtering
  // ------------------------------------------------

  const filteredFeedback = useMemo(() => {
    const query = searchQuery.toLowerCase().trim();

    return feedback.filter((item) => {
      const matchesCategory =
        activeFilter === "All" ||
        item.category === activeFilter;

      const matchesSearch =
        !query ||
        item.student.toLowerCase().includes(query) ||
        item.internship.toLowerCase().includes(query) ||
        item.university.toLowerCase().includes(query) ||
        item.id.toLowerCase().includes(query);

      return matchesCategory && matchesSearch;
    });
  }, [feedback, activeFilter, searchQuery]);

  // ------------------------------------------------
  // Feedback actions
  // ------------------------------------------------

  function updateFeedbackStatus(feedbackId, status) {
    setFeedback((previous) =>
      previous.map((item) =>
        item.id === feedbackId
          ? { ...item, status }
          : item
      )
    );

    setSelectedFeedback((previous) =>
      previous?.id === feedbackId
        ? { ...previous, status }
        : previous
    );
  }

  // ------------------------------------------------
  // Page JSX
  // ------------------------------------------------

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-7">

        {/* Page heading */}
        <section>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2 h-2 rounded-full bg-primary" />

            <span className="font-ui text-xs font-bold uppercase tracking-wider text-text-muted">
              Recruiter Workspace
            </span>
          </div>

          <h1 className="font-display text-2xl sm:text-3xl text-text tracking-tight">
            Student Feedback
          </h1>

          <p className="font-ui text-sm text-text-secondary mt-1">
            Understand student experiences and improve your internship programs.
          </p>
        </section>

        {/* Statistics */}
        <section className="grid grid-cols-2 xl:grid-cols-4 gap-3 sm:gap-4">
          <StatCard
            label="Total Feedback"
            value={stats.total}
            description="Student experiences received"
            accent="bg-primary/10 text-primary"
            icon={
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01" />
              </svg>
            }
          />

          <StatCard
            label="Average Rating"
            value={`${stats.average}/5`}
            description="Overall student satisfaction"
            accent="bg-amber-400/10 text-amber-500"
            icon={
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.96a1 1 0 00.95.69h4.165c.969 0 1.371 1.24.588 1.81l-3.37 2.449a1 1 0 00-.364 1.118l1.287 3.96c.3.922-.755 1.688-1.539 1.119l-3.37-2.449a1 1 0 00-1.176 0l-3.37 2.449c-.783.569-1.838-.197-1.539-1.118l1.287-3.96a1 1 0 00-.364-1.118L2.122 9.387c-.783-.57-.38-1.81.588-1.81h4.165a1 1 0 00.95-.69l1.224-3.96z" />
              </svg>
            }
          />

          <StatCard
            label="Positive Feedback"
            value={stats.positive}
            description="Students reporting good experiences"
            accent="bg-success/10 text-success"
            icon={
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M14 9V5a3 3 0 00-3-3l-4 9v11h11.28a2 2 0 001.97-1.65l1.38-8A2 2 0 0017.66 10H14zM7 21H4a2 2 0 01-2-2v-7a2 2 0 012-2h3" />
              </svg>
            }
          />

          <StatCard
            label="Needs Attention"
            value={stats.negative}
            description="Experiences that need improvement"
            accent="bg-danger/10 text-danger"
            icon={
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v4m0 4h.01M10.3 3.9L2.8 17a2 2 0 001.7 3h15a2 2 0 001.7-3L13.7 3.9a2 2 0 00-3.4 0z" />
              </svg>
            }
          />
        </section>

        {/* Rating overview */}
        <section className="bg-surface border border-border rounded-[var(--radius-lg)] p-5 sm:p-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h2 className="font-display text-lg font-bold text-text">
                Overall Experience Rating
              </h2>

              <p className="font-ui text-xs text-text-muted mt-1">
                Based on all submitted student feedback.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <span className="font-display text-3xl font-bold text-text tabular-nums">
                {stats.average}
              </span>

              <div>
                <StarRating
                  rating={Math.round(Number(stats.average))}
                  size="large"
                />
                <p className="font-ui text-[10px] text-text-muted mt-1">
                  Out of 5 stars
                </p>
              </div>
            </div>
          </div>

          <div className="mt-5 space-y-2">
            {[5, 4, 3, 2, 1].map((rating) => {
              const count = feedback.filter(
                (item) => item.rating === rating
              ).length;

              const percentage =
                feedback.length > 0
                  ? (count / feedback.length) * 100
                  : 0;

              return (
                <div
                  key={rating}
                  className="flex items-center gap-3"
                >
                  <span className="font-ui text-xs text-text-secondary w-8">
                    {rating} ★
                  </span>

                  <div className="flex-1 h-2 rounded-full bg-surface-alt overflow-hidden">
                    <div
                      className="h-full rounded-full bg-primary transition-all"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>

                  <span className="font-ui text-[11px] text-text-muted w-6 text-right tabular-nums">
                    {count}
                  </span>
                </div>
              );
            })}
          </div>
        </section>

        {/* Feedback list */}
        <section className="space-y-4">
          <div>
            <h2 className="font-display text-xl font-bold text-text">
              Student Experiences
            </h2>

            <p className="font-ui text-xs text-text-muted mt-1">
              Read what students have shared about their internships.
            </p>
          </div>

          {/* Search and filters */}
          <div className="bg-surface border border-border rounded-[var(--radius-lg)] p-3 sm:p-4 space-y-4">
            <div className="relative">
              <svg
                className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth={2}
              >
                <circle cx="11" cy="11" r="7" />
                <path strokeLinecap="round" d="m16 16 4 4" />
              </svg>

              <input
                type="text"
                value={searchQuery}
                onChange={(event) => setSearchQuery(event.target.value)}
                placeholder="Search by student, internship, university or feedback ID..."
                className="w-full pl-10 pr-4 py-2.5 rounded-[var(--radius-md)] bg-background border border-border text-sm text-text placeholder:text-text-muted focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
              />
            </div>

            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              {filters.map((filter) => {
                const count =
                  filter === "All"
                    ? feedback.length
                    : feedback.filter(
                        (item) => item.category === filter
                      ).length;

                return (
                  <button
                    key={filter}
                    type="button"
                    onClick={() => setActiveFilter(filter)}
                    className={`shrink-0 inline-flex items-center gap-2 px-3 py-2 rounded-lg border text-xs font-ui font-semibold transition-all ${
                      activeFilter === filter
                        ? "bg-rose-soft text-primary border-primary/20"
                        : "bg-surface text-text-secondary border-border hover:bg-surface-alt"
                    }`}
                  >
                    {filter}

                    <span className="text-[10px] opacity-70">
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Feedback cards */}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            {filteredFeedback.map((item) => (
              <div
                key={item.id}
                className="bg-surface border border-border rounded-[var(--radius-lg)] p-5 space-y-4 hover:border-primary/20 transition-colors"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <Avatar name={item.student} />

                    <div className="min-w-0">
                      <h3 className="font-ui text-sm font-bold text-text">
                        {item.student}
                      </h3>

                      <p className="font-ui text-[11px] text-text-muted mt-1 truncate">
                        {item.university}
                      </p>
                    </div>
                  </div>

                  <CategoryBadge category={item.category} />
                </div>

                <div>
                  <p className="font-ui text-xs font-bold text-text">
                    {item.internship}
                  </p>

                  <p className="font-ui text-[11px] text-text-muted mt-1">
                    {item.department} · {item.id}
                  </p>
                </div>

                <div className="flex items-center justify-between">
                  <StarRating rating={item.rating} />

                  <span className="font-ui text-[11px] text-text-muted">
                    {item.submittedAt}
                  </span>
                </div>

                <p className="font-ui text-xs text-text-secondary leading-6 line-clamp-3">
                  {item.experience}
                </p>

                <div className="pt-3 border-t border-border flex items-center justify-between gap-3">
                  <span className="font-ui text-[10px] text-text-muted">
                    {item.status}
                  </span>

                  <button
                    type="button"
                    onClick={() => setSelectedFeedback(item)}
                    className="px-3 py-2 rounded-lg border border-border text-xs font-ui font-semibold text-text-secondary hover:bg-rose-soft hover:text-primary hover:border-primary/20 transition-colors"
                  >
                    Read Feedback
                  </button>
                </div>
              </div>
            ))}
          </div>

          {filteredFeedback.length === 0 && (
            <EmptyState searchQuery={searchQuery} />
          )}
        </section>
      </div>

      {/* ==============================================
          FEEDBACK DETAILS MODAL
      ============================================== */}

      {selectedFeedback && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-6"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) {
              setSelectedFeedback(null);
            }
          }}
        >
          <div className="absolute inset-0 bg-[#21131d]/55 backdrop-blur-md" />

          <div className="relative w-full max-w-3xl max-h-[92vh] overflow-hidden rounded-2xl sm:rounded-3xl border border-white/60 dark:border-white/15 bg-white/95 dark:bg-[#211923]/95 backdrop-blur-2xl shadow-[0_30px_100px_rgba(30,10,25,0.35)]">

            {/* Header */}
            <div className="flex items-start justify-between gap-4 px-5 sm:px-7 py-5 border-b border-border">
              <div>
                <span className="font-ui text-[10px] font-bold uppercase tracking-[0.18em] text-primary">
                  Student Experience
                </span>

                <h2 className="font-display text-xl font-bold text-text mt-1">
                  Feedback Details
                </h2>

                <p className="font-ui text-xs text-text-muted mt-1">
                  {selectedFeedback.id}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSelectedFeedback(null)}
                aria-label="Close feedback"
                className="w-9 h-9 rounded-full border border-border flex items-center justify-center text-text-secondary hover:bg-rose-soft hover:text-primary transition-colors"
              >
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 6l12 12M18 6L6 18" />
                </svg>
              </button>
            </div>

            {/* Content */}
            <div className="overflow-y-auto max-h-[calc(92vh-150px)] px-5 sm:px-7 py-6 space-y-6">

              {/* Student identity */}
              <div className="flex items-center gap-3">
                <Avatar name={selectedFeedback.student} />

                <div className="flex-1 min-w-0">
                  <h3 className="font-display text-lg font-bold text-text">
                    {selectedFeedback.student}
                  </h3>

                  <p className="font-ui text-xs text-text-muted mt-1">
                    {selectedFeedback.university}
                  </p>
                </div>

                <CategoryBadge category={selectedFeedback.category} />
              </div>

              {/* Rating */}
              <section className="rounded-xl bg-surface-alt/70 border border-border p-4">
                <p className="font-ui text-[10px] font-bold uppercase tracking-wider text-text-muted">
                  Overall Rating
                </p>

                <div className="flex items-center gap-3 mt-2">
                  <StarRating rating={selectedFeedback.rating} size="large" />

                  <span className="font-display text-xl font-bold text-text">
                    {selectedFeedback.rating}/5
                  </span>
                </div>
              </section>

              {/* Internship */}
              <section className="space-y-2">
                <h3 className="font-ui text-sm font-bold text-text">
                  Internship Details
                </h3>

                <div className="rounded-xl border border-border p-4">
                  <p className="font-ui text-sm font-bold text-text">
                    {selectedFeedback.internship}
                  </p>

                  <p className="font-ui text-xs text-text-muted mt-1">
                    {selectedFeedback.department} · Submitted{" "}
                    {selectedFeedback.submittedAt}
                  </p>
                </div>
              </section>

              {/* Experience */}
              <section className="space-y-2">
                <h3 className="font-ui text-sm font-bold text-text">
                  Student Experience
                </h3>

                <p className="font-ui text-xs text-text-secondary leading-6">
                  {selectedFeedback.experience}
                </p>
              </section>

              {/* Highlights */}
              <section className="space-y-3">
                <h3 className="font-ui text-sm font-bold text-text">
                  Positive Highlights
                </h3>

                <div className="flex flex-wrap gap-2">
                  {selectedFeedback.highlights.map((highlight) => (
                    <span
                      key={highlight}
                      className="px-3 py-1.5 rounded-full bg-rose-soft text-primary text-[11px] font-ui font-semibold"
                    >
                      {highlight}
                    </span>
                  ))}
                </div>
              </section>

              {/* Improvements */}
              <section className="space-y-2">
                <h3 className="font-ui text-sm font-bold text-text">
                  Areas for Improvement
                </h3>

                <div className="rounded-xl border border-border bg-surface-alt/50 p-4">
                  <p className="font-ui text-xs text-text-secondary leading-6">
                    {selectedFeedback.improvements}
                  </p>
                </div>
              </section>
            </div>

            {/* Footer */}
            <div className="px-5 sm:px-7 py-4 border-t border-border bg-surface/80 flex items-center justify-between gap-3">
              <span className="font-ui text-[11px] text-text-muted">
                {selectedFeedback.status}
              </span>

              <button
                type="button"
                onClick={() => setSelectedFeedback(null)}
                className="px-4 py-2.5 rounded-xl bg-primary text-white font-ui text-xs font-bold hover:opacity-90 transition-opacity"
              >
                Close Feedback
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
