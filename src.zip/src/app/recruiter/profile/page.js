
"use client";

import { useRef, useState } from "react";

const initialProfile = {
  recruiterName: "Recruiter Name",
  email: "recruiter@company.com",
  phone: "+91 98765 43210",
  jobTitle: "Talent Acquisition Manager",
  companyName: "Your Company",
  website: "https://www.example.com",
  industry: "Information Technology",
  companySize: "201-500 employees",
  founded: "2015",
  location: "India",
  description:
    "We are a growing organization focused on building innovative technology solutions and providing opportunities for emerging talent.",
  contactEmail: "careers@example.com",
  linkedin: "",
  twitter: "",
};

// --------------------------------------------------
// Reusable components
// --------------------------------------------------

function ProfileSection({ title, description, children }) {
  return (
    <section className="bg-surface border border-border rounded-[var(--radius-lg)] overflow-hidden">
      <div className="px-5 sm:px-6 py-5 border-b border-border">
        <h2 className="font-display text-lg font-bold text-text">
          {title}
        </h2>

        <p className="font-ui text-xs text-text-muted mt-1">
          {description}
        </p>
      </div>

      <div className="p-5 sm:p-6">
        {children}
      </div>
    </section>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
  disabled = false,
}) {
  return (
    <label className="block space-y-2">
      <span className="font-ui text-xs font-semibold text-text-secondary">
        {label}
      </span>

      <input
        type={type}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        disabled={disabled}
        className="w-full px-4 py-3 rounded-xl bg-background border border-border text-sm text-text placeholder:text-text-muted focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all disabled:opacity-70 disabled:cursor-not-allowed"
      />
    </label>
  );
}

function SelectField({
  label,
  value,
  onChange,
  options,
  disabled = false,
}) {
  return (
    <label className="block space-y-2">
      <span className="font-ui text-xs font-semibold text-text-secondary">
        {label}
      </span>

      <select
        value={value}
        onChange={onChange}
        disabled={disabled}
        className="w-full px-4 py-3 rounded-xl bg-background border border-border text-sm text-text focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all disabled:opacity-70 disabled:cursor-not-allowed"
      >
        {options.map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </select>
    </label>
  );
}

function Avatar({ name }) {
  const initials = name
    .split(" ")
    .filter(Boolean)
    .map((part) => part[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  return (
    <div className="w-16 h-16 rounded-full bg-rose-soft text-primary flex items-center justify-center font-display text-xl font-bold">
      {initials || "R"}
    </div>
  );
}

// --------------------------------------------------
// Main page
// --------------------------------------------------

export default function RecruiterProfilePage() {
  const [profile, setProfile] = useState(initialProfile);
  const [logoPreview, setLogoPreview] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [saved, setSaved] = useState(false);

  const fileInputRef = useRef(null);

  function updateField(key, value) {
    setProfile((previous) => ({
      ...previous,
      [key]: value,
    }));

    setSaved(false);
  }

  function handleLogoChange(event) {
    const file = event.target.files?.[0];

    if (!file) return;

    if (!file.type.startsWith("image/")) {
      alert("Please select an image file.");
      event.target.value = "";
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      alert("Company logo must be smaller than 2 MB.");
      event.target.value = "";
      return;
    }

    setLogoPreview((previous) => {
      if (previous) URL.revokeObjectURL(previous);
      return URL.createObjectURL(file);
    });

    setSaved(false);
  }

  function handleRemoveLogo() {
    setLogoPreview((previous) => {
      if (previous) URL.revokeObjectURL(previous);
      return "";
    });

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }

    setSaved(false);
  }

  function handleSave() {
    setIsEditing(false);
    setSaved(true);
  }

  function handleCancel() {
    setProfile(initialProfile);
    setLogoPreview((previous) => {
      if (previous) URL.revokeObjectURL(previous);
      return "";
    });

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }

    setIsEditing(false);
    setSaved(false);
  }

  const inputProps = (key) => ({
    value: profile[key],
    onChange: (event) => updateField(key, event.target.value),
    disabled: !isEditing,
  });

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-[1100px] mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-7">

        {/* Page heading */}
        <section>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2 h-2 rounded-full bg-primary" />

            <span className="font-ui text-xs font-bold uppercase tracking-wider text-text-muted">
              Recruiter Workspace
            </span>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
            <div>
              <h1 className="font-display text-2xl sm:text-3xl text-text tracking-tight">
                Company Profile
              </h1>

              <p className="font-ui text-sm text-text-secondary mt-1">
                Manage your recruiter and company information.
              </p>
            </div>

            {!isEditing ? (
              <button
                type="button"
                onClick={() => {
                  setIsEditing(true);
                  setSaved(false);
                }}
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-primary text-white font-ui text-xs font-bold hover:opacity-90 transition-opacity"
              >
                <svg
                  className="w-4 h-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth={1.8}
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M16 4l4 4M4 20l4-.8L19 8a2.1 2.1 0 00-3-3L5 16l-1 4z"
                  />
                </svg>
                Edit Profile
              </button>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleCancel}
                  className="px-4 py-2.5 rounded-xl border border-border text-text-secondary font-ui text-xs font-bold hover:bg-surface-alt"
                >
                  Cancel
                </button>

                <button
                  type="button"
                  onClick={handleSave}
                  className="px-5 py-2.5 rounded-xl bg-primary text-white font-ui text-xs font-bold hover:opacity-90"
                >
                  Save Changes
                </button>
              </div>
            )}
          </div>
        </section>

        {/* Company identity */}
        <ProfileSection
          title="Company Identity"
          description="Your company's public identity on InternCheck."
        >
          <div className="flex flex-col sm:flex-row sm:items-center gap-5">
            <div>
              {logoPreview ? (
                <img
                  src={logoPreview}
                  alt="Company logo preview"
                  className="w-20 h-20 rounded-2xl object-cover border border-border"
                />
              ) : (
                <div className="w-20 h-20 rounded-2xl bg-rose-soft text-primary flex items-center justify-center font-display text-2xl font-bold border border-primary/10">
                  {profile.companyName.slice(0, 1).toUpperCase()}
                </div>
              )}
            </div>

            <div className="flex-1">
              <h3 className="font-display text-lg font-bold text-text">
                {profile.companyName}
              </h3>

              <p className="font-ui text-xs text-text-muted mt-1">
                Company logo · PNG, JPG or WebP · Max 2 MB
              </p>

              {isEditing && (
                <div className="flex flex-wrap gap-2 mt-3">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/png,image/jpeg,image/webp"
                    onChange={handleLogoChange}
                    className="hidden"
                  />

                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3 py-2 rounded-lg bg-rose-soft text-primary text-xs font-ui font-bold hover:bg-primary hover:text-white transition-colors"
                  >
                    Upload Logo
                  </button>

                  {logoPreview && (
                    <button
                      type="button"
                      onClick={handleRemoveLogo}
                      className="px-3 py-2 rounded-lg border border-border text-text-secondary text-xs font-ui font-bold"
                    >
                      Remove
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        </ProfileSection>

        {/* Recruiter information */}
        <ProfileSection
          title="Recruiter Information"
          description="Your personal details and professional contact information."
        >
          <div className="flex items-center gap-4 pb-5 mb-5 border-b border-border">
            <Avatar name={profile.recruiterName} />

            <div>
              <h3 className="font-ui text-sm font-bold text-text">
                {profile.recruiterName}
              </h3>

              <p className="font-ui text-xs text-text-muted mt-1">
                {profile.jobTitle}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <Field
              label="Full Name"
              {...inputProps("recruiterName")}
            />

            <Field
              label="Email Address"
              type="email"
              {...inputProps("email")}
            />

            <Field
              label="Phone Number"
              type="tel"
              {...inputProps("phone")}
            />

            <Field
              label="Job Title"
              {...inputProps("jobTitle")}
            />
          </div>
        </ProfileSection>

        {/* Company information */}
        <ProfileSection
          title="Company Information"
          description="Tell students more about the organization offering internships."
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <Field
              label="Company Name"
              {...inputProps("companyName")}
            />

            <Field
              label="Company Website"
              type="url"
              {...inputProps("website")}
            />

            <SelectField
              label="Industry"
              value={profile.industry}
              onChange={(event) =>
                updateField("industry", event.target.value)
              }
              disabled={!isEditing}
              options={[
                "Information Technology",
                "Software Development",
                "Education",
                "Healthcare",
                "Finance",
                "Marketing",
                "Manufacturing",
                "E-commerce",
                "Other",
              ]}
            />

            <SelectField
              label="Company Size"
              value={profile.companySize}
              onChange={(event) =>
                updateField("companySize", event.target.value)
              }
              disabled={!isEditing}
              options={[
                "1-10 employees",
                "11-50 employees",
                "51-200 employees",
                "201-500 employees",
                "501-1000 employees",
                "1000+ employees",
              ]}
            />

            <Field
              label="Year Founded"
              {...inputProps("founded")}
            />

            <Field
              label="Company Location"
              {...inputProps("location")}
            />
          </div>

          <div className="mt-5">
            <label className="block space-y-2">
              <span className="font-ui text-xs font-semibold text-text-secondary">
                Company Description
              </span>

              <textarea
                value={profile.description}
                onChange={(event) =>
                  updateField("description", event.target.value)
                }
                disabled={!isEditing}
                rows={5}
                placeholder="Describe your company, its mission and what it does..."
                className="w-full px-4 py-3 rounded-xl bg-background border border-border text-sm text-text placeholder:text-text-muted focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all disabled:opacity-70 disabled:cursor-not-allowed resize-y"
              />
            </label>
          </div>
        </ProfileSection>

        {/* Contact and social links */}
        <ProfileSection
          title="Contact and Social Links"
          description="Give students ways to learn more about your company."
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <Field
              label="Careers Contact Email"
              type="email"
              {...inputProps("contactEmail")}
            />

            <Field
              label="LinkedIn URL"
              type="url"
              placeholder="https://linkedin.com/company/..."
              {...inputProps("linkedin")}
            />

            <Field
              label="Twitter / X URL"
              type="url"
              placeholder="https://x.com/..."
              {...inputProps("twitter")}
            />
          </div>
        </ProfileSection>

        {/* Save confirmation */}
        {saved && (
          <div className="flex items-center gap-2 rounded-xl border border-success/20 bg-success/5 px-4 py-3">
            <svg
              className="w-4 h-4 text-success"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M5 12l4 4L19 6"
              />
            </svg>

            <p className="font-ui text-xs font-semibold text-success">
              Profile changes saved in this session.
            </p>
          </div>
        )}

        {/* Bottom actions */}
        {isEditing && (
          <div className="flex justify-end gap-3 pb-6">
            <button
              type="button"
              onClick={handleCancel}
              className="px-5 py-3 rounded-xl border border-border text-text-secondary font-ui text-xs font-bold hover:bg-surface-alt"
            >
              Cancel
            </button>

            <button
              type="button"
              onClick={handleSave}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-primary text-white font-ui text-xs font-bold hover:opacity-90"
            >
              <svg
                className="w-4 h-4"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth={2}
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M5 12l4 4L19 6"
                />
              </svg>
              Save Profile
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
