
"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import RecruiterSectionHeader from "@/components/shared/recruiter/RecruiterSectionHeader";

const initialFormData = {
    title: "",
    category: "",
    description: "",
    requiredSkills: "",
    preferredSkills: "",
    workMode: "remote",
    city: "",
    state: "",
    country: "India",
    stipendAmount: "",
    stipendPeriod: "monthly",
    durationValue: "",
    durationUnit: "months",
    deadline: "",
    applicationMethod: "internal",
    applicationUrl: "",
    degrees: "",
    graduationYears: "",
    otherRequirements: "",
};

const FILTERS = [
    { label: "All", value: "" },
    { label: "Active", value: "active" },
    { label: "Pending", value: "pending" },
    { label: "Draft", value: "draft" },
    { label: "Rejected", value: "rejected" },
    { label: "Withdrawn", value: "withdrawn" },
    { label: "Expired", value: "expired" },
];

const STATUS_STYLES = {
    active: "bg-success/10 text-success border-success/20",
    pending: "bg-warning/10 text-warning border-warning/20",
    draft: "bg-surface-alt text-text-muted border-border",
    rejected: "bg-danger/10 text-danger border-danger/20",
    withdrawn: "bg-surface-alt text-text-muted border-border",
    expired: "bg-surface-alt text-text-muted border-border",
};

function formatStatus(status) {
    return status
        ? status.charAt(0).toUpperCase() + status.slice(1)
        : "Unknown";
}

function formatDate(date) {
    if (!date) return "Not specified";

    const parsed = new Date(date);

    if (Number.isNaN(parsed.getTime())) {
        return "Not specified";
    }

    return parsed.toLocaleDateString("en-IN", {
        day: "numeric",
        month: "short",
        year: "numeric",
    });
}

function formatLocation(internship) {
    const location = internship.location || {};

    const parts = [
        location.city,
        location.state,
        location.country,
    ].filter(Boolean);

    return parts.length
        ? parts.join(", ")
        : formatStatus(internship.workMode || "unspecified");
}

function formatStipend(stipend = {}) {
    if (
        stipend.period === "unpaid" ||
        stipend.amount === null ||
        stipend.amount === undefined
    ) {
        return stipend.period === "unpaid"
            ? "Unpaid"
            : "Not specified";
    }

    const amount = new Intl.NumberFormat("en-IN", {
        maximumFractionDigits: 0,
    }).format(stipend.amount);

    const currency = stipend.currency || "INR";

    const periodLabels = {
        hourly: "/hour",
        weekly: "/week",
        monthly: "/month",
        total: " total",
    };

    return `${currency} ${amount}${periodLabels[stipend.period] || ""}`;
}

function StatusBadge({ status }) {
    return (
        <span
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[11px] font-bold font-ui ${
                STATUS_STYLES[status] || STATUS_STYLES.draft
            }`}
        >
            <span className="w-1.5 h-1.5 rounded-full bg-current" />
            {formatStatus(status)}
        </span>
    );
}

function StatCard({ label, value, description, icon, accent }) {
    return (
        <div className="bg-surface border border-border rounded-[var(--radius-lg)] p-4 sm:p-5">
            <div className="flex items-start justify-between gap-3">
                <div>
                    <p className="font-ui text-xs text-text-secondary font-medium">
                        {label}
                    </p>

                    <h3 className="font-display text-2xl font-bold text-text mt-2">
                        {value}
                    </h3>

                    <p className="font-ui text-[11px] text-text-muted mt-1">
                        {description}
                    </p>
                </div>

                <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center ${accent}`}
                >
                    {icon}
                </div>
            </div>
        </div>
    );
}

function EmptyState({ searchQuery }) {
    return (
        <div className="bg-surface border border-border rounded-[var(--radius-lg)] py-14 px-5 text-center">
            <div className="mx-auto w-12 h-12 rounded-full bg-surface-alt flex items-center justify-center text-text-muted mb-3">
                <svg
                    className="w-6 h-6"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={1.8}
                >
                    <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M8 7h8m-8 5h8m-8 5h4m-7 4h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v14a2 2 0 002 2z"
                    />
                </svg>
            </div>

            <h3 className="font-ui text-sm font-bold text-text">
                No internships found
            </h3>

            <p className="font-ui text-xs text-text-muted mt-1">
                {searchQuery
                    ? "Try changing your search or selected filter."
                    : "Your internships will appear here."}
            </p>
        </div>
    );
}

function FormField({
    label,
    name,
    value,
    onChange,
    placeholder,
    type = "text",
    required = false,
    min,
    options,
}) {
    const commonClass =
        "w-full px-3.5 py-3 rounded-xl bg-white/60 dark:bg-white/5 border border-border text-sm text-text placeholder:text-text-muted outline-none focus:border-primary focus:ring-2 focus:ring-primary/10 transition-all";

    return (
        <div>
            <label className="block font-ui text-xs font-semibold text-text-secondary mb-1.5">
                {label} {required && "*"}
            </label>

            {options ? (
                <select
                    name={name}
                    value={value}
                    onChange={onChange}
                    required={required}
                    className={commonClass}
                >
                    {options.map((option) => (
                        <option key={option.value} value={option.value}>
                            {option.label}
                        </option>
                    ))}
                </select>
            ) : (
                <input
                    type={type}
                    name={name}
                    value={value}
                    onChange={onChange}
                    placeholder={placeholder}
                    required={required}
                    min={min}
                    className={commonClass}
                />
            )}
        </div>
    );
}

export default function RecruiterInternshipsPage() {
    const [internships, setInternships] = useState([]);
    const [stats, setStats] = useState({
        total: 0,
        active: 0,
        pending: 0,
        applicants: 0,
        draft: 0,
        rejected: 0,
        withdrawn: 0,
        expired: 0,
    });

    const [formData, setFormData] = useState(initialFormData);

    const [activeFilter, setActiveFilter] = useState("");
    const [searchQuery, setSearchQuery] = useState("");

    const [showPostModal, setShowPostModal] = useState(false);
    const [showWithdrawConfirm, setShowWithdrawConfirm] = useState(false);

    const [selectedInternship, setSelectedInternship] = useState(null);
    const [editingInternship, setEditingInternship] = useState(null);

    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [actionLoading, setActionLoading] = useState(false);

    const [error, setError] = useState("");
    const [successMessage, setSuccessMessage] = useState("");

    const fetchInternships = useCallback(async () => {
        setLoading(true);
        setError("");

        try {
            const params = new URLSearchParams({
                page: "1",
                limit: "100",
            });

            if (activeFilter) {
                params.set("status", activeFilter);
            }

            if (searchQuery.trim()) {
                params.set("search", searchQuery.trim());
            }

            const response = await fetch(
                `/api/recruiter/internships?${params.toString()}`,
                {
                    method: "GET",
                    credentials: "include",
                    cache: "no-store",
                }
            );

            const result = await response.json();

            if (!response.ok || !result.success) {
                throw new Error(
                    result.message || "Unable to load internships."
                );
            }

            setInternships(result.data || []);

            setStats(result.stats || {
                total: 0,
                active: 0,
                pending: 0,
                applicants: 0,
                draft: 0,
                rejected: 0,
                withdrawn: 0,
                expired: 0,
            });
        } catch (err) {
            setError(
                err.message || "Unable to load internships."
            );
        } finally {
            setLoading(false);
        }
    }, [activeFilter, searchQuery]);

    useEffect(() => {
        const timeout = setTimeout(() => {
            fetchInternships();
        }, searchQuery ? 350 : 0);

        return () => clearTimeout(timeout);
    }, [fetchInternships, searchQuery]);

    function handleFormChange(event) {
        const { name, value } = event.target;

        setFormData((previous) => ({
            ...previous,
            [name]: value,
        }));
    }

    function closePostModal() {
        if (saving) return;

        setShowPostModal(false);
        setEditingInternship(null);
        setFormData(initialFormData);
    }

    function openCreateModal() {
        setEditingInternship(null);
        setFormData(initialFormData);
        setShowPostModal(true);
        setError("");
        setSuccessMessage("");
    }

    function openEditModal(internship) {
        if (!["draft", "active"].includes(internship.status)) {
            return;
        }

        setEditingInternship(internship);

        setFormData({
            title: internship.title || "",
            category: internship.category || "",
            description: internship.description || "",
            requiredSkills: (internship.requiredSkills || []).join(", "),
            preferredSkills: (internship.preferredSkills || []).join(", "),
            workMode: internship.workMode || "remote",
            city: internship.location?.city || "",
            state: internship.location?.state || "",
            country: internship.location?.country || "India",
            stipendAmount:
                internship.stipend?.amount ?? "",
            stipendPeriod:
                internship.stipend?.period || "monthly",
            durationValue:
                internship.duration?.value ?? "",
            durationUnit:
                internship.duration?.unit || "months",
            deadline: internship.applicationDeadline
                ? new Date(internship.applicationDeadline)
                    .toISOString()
                    .slice(0, 10)
                : "",
            applicationMethod:
                internship.applicationMethod || "internal",
            applicationUrl:
                internship.applicationUrl || "",
            degrees: (
                internship.eligibility?.degrees || []
            ).join(", "),
            graduationYears: (
                internship.eligibility?.graduationYears || []
            ).join(", "),
            otherRequirements:
                internship.eligibility?.otherRequirements || "",
        });

        setShowPostModal(true);
        setError("");
        setSuccessMessage("");
    }

    function buildPayload() {
        const requiredSkills = formData.requiredSkills
            .split(",")
            .map((item) => item.trim())
            .filter(Boolean);

        const preferredSkills = formData.preferredSkills
            .split(",")
            .map((item) => item.trim())
            .filter(Boolean);

        const degrees = formData.degrees
            .split(",")
            .map((item) => item.trim())
            .filter(Boolean);

        const graduationYears = formData.graduationYears
            .split(",")
            .map((item) => Number(item.trim()))
            .filter(Number.isFinite);

        const stipendAmount =
            formData.stipendAmount === ""
                ? null
                : Number(formData.stipendAmount);

        const durationValue =
            formData.durationValue === ""
                ? null
                : Number(formData.durationValue);

        return {
            title: formData.title.trim(),
            category: formData.category.trim(),
            description: formData.description.trim(),

            requiredSkills,
            preferredSkills,

            workMode: formData.workMode,

            location: {
                city: formData.city.trim(),
                state: formData.state.trim(),
                country: formData.country.trim(),
            },

            stipend: {
                amount: stipendAmount,
                currency: "INR",
                period:
                    formData.stipendPeriod === "unpaid"
                        ? "unpaid"
                        : formData.stipendPeriod,
            },

            duration: {
                value: durationValue,
                unit: durationValue ? formData.durationUnit : null,
            },

            eligibility: {
                degrees,
                graduationYears,
                otherRequirements:
                    formData.otherRequirements.trim(),
            },

            applicationMethod: formData.applicationMethod,

            applicationUrl:
                formData.applicationMethod === "external"
                    ? formData.applicationUrl.trim()
                    : null,

            applicationDeadline: formData.deadline || null,
        };
    }

    async function saveInternship(shouldSubmit = false) {
        setError("");
        setSuccessMessage("");

        if (
            !formData.title.trim() ||
            !formData.category.trim() ||
            !formData.description.trim()
        ) {
            setError(
                "Internship title, category and description are required."
            );
            return;
        }

        if (
            formData.applicationMethod === "external" &&
            !formData.applicationUrl.trim()
        ) {
            setError(
                "An application URL is required for external applications."
            );
            return;
        }

        const payload = buildPayload();

        if (
            payload.stipend.amount !== null &&
            (
                !Number.isFinite(payload.stipend.amount) ||
                payload.stipend.amount < 0
            )
        ) {
            setError("Enter a valid stipend amount.");
            return;
        }

        if (
            payload.duration.value !== null &&
            (
                !Number.isFinite(payload.duration.value) ||
                payload.duration.value < 1
            )
        ) {
            setError("Duration must be at least one unit.");
            return;
        }

        if (
            payload.eligibility.graduationYears.some(
                (year) => year < 2000 || year > 2100
            )
        ) {
            setError("Enter valid graduation years.");
            return;
        }

        setSaving(true);

        try {
            const isEditing = Boolean(editingInternship);

            const response = await fetch(
                isEditing
                    ? `/api/internships/${editingInternship._id}`
                    : "/api/internships",
                {
                    method: isEditing ? "PATCH" : "POST",
                    credentials: "include",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify(payload),
                }
            );

            const result = await response.json();

            if (!response.ok || !result.success) {
                throw new Error(
                    result.message || "Unable to save internship."
                );
            }

            const savedInternship = result.data;

            if (shouldSubmit) {
                if (isEditing && savedInternship.status !== "draft") {
                    throw new Error(
                        "This listing must be in draft status before submission."
                    );
                }

                const submitResponse = await fetch(
                    `/api/internships/${savedInternship._id}/submit`,
                    {
                        method: "POST",
                        credentials: "include",
                    }
                );

                const submitResult = await submitResponse.json();

                if (
                    !submitResponse.ok ||
                    !submitResult.success
                ) {
                    throw new Error(
                        submitResult.message ||
                        "Internship saved, but submission failed. You can submit it from the listings page."
                    );
                }

                setSuccessMessage(
                    "Internship submitted successfully."
                );
            } else {
                setSuccessMessage(
                    isEditing
                        ? "Internship updated successfully."
                        : "Internship saved as a draft."
                );
            }

            setShowPostModal(false);
            setEditingInternship(null);
            setFormData(initialFormData);

            setActiveFilter("");
            setSearchQuery("");

            await fetchInternships();
        } catch (err) {
            setError(
                err.message || "Unable to save internship."
            );
        } finally {
            setSaving(false);
        }
    }

    async function submitDraft(internship) {
        setActionLoading(true);
        setError("");
        setSuccessMessage("");

        try {
            const response = await fetch(
                `/api/internships/${internship._id}/submit`,
                {
                    method: "POST",
                    credentials: "include",
                }
            );

            const result = await response.json();

            if (!response.ok || !result.success) {
                throw new Error(
                    result.message || "Unable to submit internship."
                );
            }

            setSuccessMessage(
                "Internship submitted for verification."
            );

            await fetchInternships();
        } catch (err) {
            setError(
                err.message || "Unable to submit internship."
            );
        } finally {
            setActionLoading(false);
        }
    }

    async function withdrawInternship() {
        if (!selectedInternship) return;

        setActionLoading(true);
        setError("");
        setSuccessMessage("");

        try {
            const response = await fetch(
                `/api/internships/${selectedInternship._id}/withdraw`,
                {
                    method: "PATCH",
                    credentials: "include",
                }
            );

            const result = await response.json();

            if (!response.ok || !result.success) {
                throw new Error(
                    result.message || "Unable to withdraw internship."
                );
            }

            setShowWithdrawConfirm(false);
            setSelectedInternship(null);

            setSuccessMessage(
                "Internship withdrawn successfully."
            );

            await fetchInternships();
        } catch (err) {
            setError(
                err.message || "Unable to withdraw internship."
            );
        } finally {
            setActionLoading(false);
        }
    }

    const filterCounts = useMemo(() => ({
        "": stats.total,
        active: stats.active,
        pending: stats.pending,
        draft: stats.draft,
        rejected: stats.rejected,
        withdrawn: stats.withdrawn,
        expired: stats.expired,
    }), [stats]);

    return (
        <div className="min-h-screen bg-background">
            <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-7">

                {/* Page heading */}
                <section className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
                    <div>
                        <div className="flex items-center gap-2 mb-1">
                            <span className="w-2 h-2 rounded-full bg-primary" />

                            <span className="font-ui text-xs font-bold uppercase tracking-wider text-text-muted">
                                Recruiter Workspace
                            </span>
                        </div>

                        <h1 className="font-display text-2xl sm:text-3xl text-text tracking-tight">
                            Internship Listings
                        </h1>

                        <p className="font-ui text-sm text-text-secondary mt-1">
                            Create, manage and track your internship opportunities.
                        </p>
                    </div>

                    <button
                        type="button"
                        onClick={openCreateModal}
                        className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-[var(--radius-md)] bg-primary text-white font-ui text-xs font-bold hover:opacity-90 transition-opacity shadow-sm"
                    >
                        <svg
                            className="w-4 h-4"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            strokeWidth={2}
                        >
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                d="M12 5v14m7-7H5"
                            />
                        </svg>

                        Post Internship
                    </button>
                </section>

                {/* Alerts */}
                {error && (
                    <div className="rounded-xl border border-danger/20 bg-danger/5 px-4 py-3 flex items-start justify-between gap-3">
                        <p className="font-ui text-xs text-danger">
                            {error}
                        </p>

                        <button
                            type="button"
                            onClick={() => setError("")}
                            className="text-danger text-xs font-bold"
                        >
                            Dismiss
                        </button>
                    </div>
                )}

                {successMessage && (
                    <div className="rounded-xl border border-success/20 bg-success/5 px-4 py-3 flex items-start justify-between gap-3">
                        <p className="font-ui text-xs text-success">
                            {successMessage}
                        </p>

                        <button
                            type="button"
                            onClick={() => setSuccessMessage("")}
                            className="text-success text-xs font-bold"
                        >
                            Dismiss
                        </button>
                    </div>
                )}

                {/* Statistics */}
                <section className="grid grid-cols-2 xl:grid-cols-4 gap-3 sm:gap-4">
                    <StatCard
                        label="Total Listings"
                        value={stats.total}
                        description="All your opportunities"
                        accent="bg-primary/10 text-primary"
                        icon={
                            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                                <path strokeLinecap="round" strokeLinejoin="round" d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01" />
                            </svg>
                        }
                    />

                    <StatCard
                        label="Active Listings"
                        value={stats.active}
                        description="Accepting applications"
                        accent="bg-success/10 text-success"
                        icon={
                            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                                <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 0a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        }
                    />

                    <StatCard
                        label="Pending Review"
                        value={stats.pending}
                        description="Awaiting assessment"
                        accent="bg-warning/10 text-warning"
                        icon={
                            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                                <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6l4 2m5-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        }
                    />

                    <StatCard
                        label="Total Applicants"
                        value={stats.applicants}
                        description="Across all listings"
                        accent="bg-rose-soft text-primary"
                        icon={
                            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                                <path strokeLinecap="round" strokeLinejoin="round" d="M16 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2m16 0v-2a4 4 0 00-3-3.87M10 11a4 4 0 100-8 4 4 0 000 8zm8-7.87a4 4 0 010 7.75" />
                            </svg>
                        }
                    />
                </section>

                {/* Listings */}
                <section className="space-y-4">
                    <RecruiterSectionHeader
                        title="Your Internships"
                        subtitle="Manage your published, pending and draft opportunities."
                    />

                    {/* Search and filters */}
                    <div className="bg-surface border border-border rounded-[var(--radius-lg)] p-3 sm:p-4 space-y-4">
                        <div className="relative">
                            <svg
                                className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                                strokeWidth={2}
                            >
                                <circle cx="11" cy="11" r="7" />
                                <path strokeLinecap="round" d="m16 16 4 4" />
                            </svg>

                            <input
                                type="text"
                                value={searchQuery}
                                onChange={(event) =>
                                    setSearchQuery(event.target.value)
                                }
                                placeholder="Search by title, category or skills..."
                                className="w-full pl-10 pr-4 py-2.5 rounded-[var(--radius-md)] bg-background border border-border text-sm text-text placeholder:text-text-muted focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                            />
                        </div>

                        <div className="flex items-center gap-2 overflow-x-auto pb-1">
                            {FILTERS.map((filter) => (
                                <button
                                    key={filter.value}
                                    type="button"
                                    onClick={() => setActiveFilter(filter.value)}
                                    className={`shrink-0 inline-flex items-center gap-2 px-3 py-2 rounded-lg border text-xs font-ui font-semibold transition-all ${
                                        activeFilter === filter.value
                                            ? "bg-rose-soft text-primary border-primary/20"
                                            : "bg-surface text-text-secondary border-border hover:bg-surface-alt"
                                    }`}
                                >
                                    {filter.label}

                                    <span className="text-[10px] opacity-70">
                                        {filterCounts[filter.value] || 0}
                                    </span>
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Loading */}
                    {loading && (
                        <div className="bg-surface border border-border rounded-[var(--radius-lg)] py-16 text-center">
                            <div className="w-7 h-7 border-2 border-primary/20 border-t-primary rounded-full animate-spin mx-auto" />

                            <p className="font-ui text-xs text-text-muted mt-3">
                                Loading internships...
                            </p>
                        </div>
                    )}

                    {/* Empty state */}
                    {!loading && internships.length === 0 && (
                        <EmptyState searchQuery={searchQuery} />
                    )}

                    {/* Desktop table */}
                    {!loading && internships.length > 0 && (
                        <>
                            <div className="hidden lg:block bg-surface border border-border rounded-[var(--radius-lg)] overflow-hidden">
                                <div className="overflow-x-auto">
                                    <table className="w-full text-left">
                                        <thead className="bg-surface-alt border-b border-border">
                                            <tr>
                                                {[
                                                    "Internship",
                                                    "Location",
                                                    "Applicants",
                                                    "Deadline",
                                                    "Status",
                                                    "Actions",
                                                ].map((heading) => (
                                                    <th
                                                        key={heading}
                                                        className={`px-5 py-3 font-ui text-[11px] uppercase tracking-wider text-text-muted font-bold ${
                                                            heading === "Actions"
                                                                ? "text-right"
                                                                : ""
                                                        }`}
                                                    >
                                                        {heading}
                                                    </th>
                                                ))}
                                            </tr>
                                        </thead>

                                        <tbody className="divide-y divide-border">
                                            {internships.map((internship) => (
                                                <tr
                                                    key={internship._id}
                                                    className="hover:bg-surface-alt/60 transition-colors"
                                                >
                                                    <td className="px-5 py-4">
                                                        <p className="font-ui text-sm font-bold text-text">
                                                            {internship.title}
                                                        </p>

                                                        <p className="font-ui text-[11px] text-text-muted mt-1">
                                                            {internship.category}
                                                        </p>
                                                    </td>

                                                    <td className="px-5 py-4">
                                                        <p className="font-ui text-xs text-text-secondary">
                                                            {formatLocation(internship)}
                                                        </p>

                                                        <p className="font-ui text-[11px] text-text-muted mt-1">
                                                            {formatStatus(internship.workMode)}
                                                        </p>
                                                    </td>

                                                    <td className="px-5 py-4">
                                                        <span className="font-ui text-sm font-semibold text-text">
                                                            {internship.applicantCount || 0}
                                                        </span>
                                                    </td>

                                                    <td className="px-5 py-4">
                                                        <p className="font-ui text-xs text-text-secondary">
                                                            {formatDate(internship.applicationDeadline)}
                                                        </p>
                                                    </td>

                                                    <td className="px-5 py-4">
                                                        <StatusBadge status={internship.status} />
                                                    </td>

                                                    <td className="px-5 py-4">
                                                        <div className="flex items-center justify-end gap-2">
                                                            {["draft", "active"].includes(internship.status) && (
                                                                <button
                                                                    type="button"
                                                                    onClick={() => openEditModal(internship)}
                                                                    className="px-3 py-1.5 rounded-md border border-border text-xs font-ui font-semibold text-text-secondary hover:bg-surface-alt transition-colors"
                                                                >
                                                                    Edit
                                                                </button>
                                                            )}

                                                            {internship.status === "draft" && (
                                                                <button
                                                                    type="button"
                                                                    disabled={actionLoading}
                                                                    onClick={() => submitDraft(internship)}
                                                                    className="px-3 py-1.5 rounded-md bg-primary text-white text-xs font-ui font-semibold hover:opacity-90 disabled:opacity-50"
                                                                >
                                                                    Submit
                                                                </button>
                                                            )}

                                                            {["active", "pending"].includes(internship.status) && (
                                                                <button
                                                                    type="button"
                                                                    onClick={() => {
                                                                        setSelectedInternship(internship);
                                                                        setShowWithdrawConfirm(true);
                                                                    }}
                                                                    className="px-3 py-1.5 rounded-md border border-danger/20 text-xs font-ui font-semibold text-danger hover:bg-danger/5 transition-colors"
                                                                >
                                                                    Withdraw
                                                                </button>
                                                            )}
                                                        </div>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            {/* Mobile cards */}
                            <div className="lg:hidden space-y-3">
                                {internships.map((internship) => (
                                    <div
                                        key={internship._id}
                                        className="bg-surface border border-border rounded-[var(--radius-lg)] p-4 space-y-4"
                                    >
                                        <div className="flex items-start justify-between gap-3">
                                            <div className="min-w-0">
                                                <h3 className="font-ui text-sm font-bold text-text">
                                                    {internship.title}
                                                </h3>

                                                <p className="font-ui text-[11px] text-text-muted mt-1">
                                                    {internship.category}
                                                </p>
                                            </div>

                                            <StatusBadge status={internship.status} />
                                        </div>

                                        <div className="grid grid-cols-2 gap-3">
                                            <div>
                                                <p className="text-[10px] uppercase tracking-wider text-text-muted font-bold">
                                                    Location
                                                </p>

                                                <p className="text-xs text-text-secondary mt-1">
                                                    {formatLocation(internship)}
                                                </p>
                                            </div>

                                            <div>
                                                <p className="text-[10px] uppercase tracking-wider text-text-muted font-bold">
                                                    Applicants
                                                </p>

                                                <p className="text-xs text-text-secondary mt-1">
                                                    {internship.applicantCount || 0}
                                                </p>
                                            </div>

                                            <div>
                                                <p className="text-[10px] uppercase tracking-wider text-text-muted font-bold">
                                                    Stipend
                                                </p>

                                                <p className="text-xs text-text-secondary mt-1">
                                                    {formatStipend(internship.stipend)}
                                                </p>
                                            </div>

                                            <div>
                                                <p className="text-[10px] uppercase tracking-wider text-text-muted font-bold">
                                                    Deadline
                                                </p>

                                                <p className="text-xs text-text-secondary mt-1">
                                                    {formatDate(internship.applicationDeadline)}
                                                </p>
                                            </div>
                                        </div>

                                        <div className="pt-3 border-t border-border flex flex-wrap items-center justify-end gap-2">
                                            {["draft", "active"].includes(internship.status) && (
                                                <button
                                                    type="button"
                                                    onClick={() => openEditModal(internship)}
                                                    className="px-3 py-2 rounded-md border border-border text-xs font-ui font-semibold text-text-secondary hover:bg-surface-alt"
                                                >
                                                    Edit
                                                </button>
                                            )}

                                            {internship.status === "draft" && (
                                                <button
                                                    type="button"
                                                    disabled={actionLoading}
                                                    onClick={() => submitDraft(internship)}
                                                    className="px-3 py-2 rounded-md bg-primary text-white text-xs font-ui font-semibold disabled:opacity-50"
                                                >
                                                    Submit
                                                </button>
                                            )}

                                            {["active", "pending"].includes(internship.status) && (
                                                <button
                                                    type="button"
                                                    onClick={() => {
                                                        setSelectedInternship(internship);
                                                        setShowWithdrawConfirm(true);
                                                    }}
                                                    className="px-3 py-2 rounded-md border border-danger/20 text-xs font-ui font-semibold text-danger hover:bg-danger/5"
                                                >
                                                    Withdraw
                                                </button>
                                            )}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </>
                    )}
                </section>
            </div>

            {/* Withdraw confirmation */}
            {showWithdrawConfirm && selectedInternship && (
                <div className="fixed inset-0 z-[60] bg-black/40 backdrop-blur-sm flex items-center justify-center p-4">
                    <div className="w-full max-w-md bg-surface border border-border rounded-2xl shadow-xl p-5 sm:p-6">
                        <div className="w-11 h-11 rounded-full bg-danger/10 text-danger flex items-center justify-center mb-4">
                            <svg
                                className="w-5 h-5"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                                strokeWidth={2}
                            >
                                <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    d="M12 9v4m0 4h.01M10.3 3.9L1.8 18.6A2 2 0 003.5 21h17a2 2 0 001.7-2.4L13.7 3.9a2 2 0 00-3.4 0z"
                                />
                            </svg>
                        </div>

                        <h3 className="font-display text-lg font-bold text-text">
                            Withdraw this internship?
                        </h3>

                        <p className="font-ui text-xs text-text-secondary mt-2 leading-5">
                            You are about to withdraw
                            {" "}
                            <strong>{selectedInternship.title}</strong>.
                            This listing will no longer accept applications.
                        </p>

                        <div className="flex items-center justify-end gap-2 mt-6">
                            <button
                                type="button"
                                disabled={actionLoading}
                                onClick={() => {
                                    setSelectedInternship(null);
                                    setShowWithdrawConfirm(false);
                                }}
                                className="px-4 py-2 rounded-lg border border-border text-xs font-ui font-semibold text-text-secondary hover:bg-surface-alt disabled:opacity-50"
                            >
                                Cancel
                            </button>

                            <button
                                type="button"
                                disabled={actionLoading}
                                onClick={withdrawInternship}
                                className="px-4 py-2 rounded-lg bg-danger text-white text-xs font-ui font-bold hover:opacity-90 disabled:opacity-50"
                            >
                                {actionLoading ? "Withdrawing..." : "Confirm Withdrawal"}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Create / Edit modal */}
            {showPostModal && (
                <div
                    className="fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-6"
                    onMouseDown={(event) => {
                        if (event.target === event.currentTarget) {
                            closePostModal();
                        }
                    }}
                >
                    <div className="absolute inset-0 bg-[#21131d]/55 backdrop-blur-md" />

                    <div className="relative w-full max-w-5xl max-h-[94vh] overflow-hidden rounded-2xl sm:rounded-3xl border border-white/60 dark:border-white/15 bg-white/90 dark:bg-[#211923]/95 backdrop-blur-2xl shadow-[0_30px_100px_rgba(30,10,25,0.35)]">
                        <div className="absolute -top-32 -right-20 w-80 h-80 rounded-full bg-rose-300/20 blur-3xl pointer-events-none" />

                        {/* Modal header */}
                        <div className="relative flex items-center justify-between gap-4 px-5 sm:px-8 py-5 border-b border-border/70">
                            <div>
                                <div className="flex items-center gap-2 mb-1">
                                    <span className="w-2 h-2 rounded-full bg-primary" />

                                    <span className="font-ui text-[10px] font-bold uppercase tracking-[0.18em] text-primary">
                                        Recruiter Workspace
                                    </span>
                                </div>

                                <h2 className="font-display text-xl sm:text-2xl font-bold text-text">
                                    {editingInternship
                                        ? "Edit Internship"
                                        : "Create an Internship"}
                                </h2>

                                <p className="font-ui text-xs text-text-secondary mt-1">
                                    Provide accurate details about this opportunity.
                                </p>
                            </div>

                            <button
                                type="button"
                                onClick={closePostModal}
                                disabled={saving}
                                aria-label="Close form"
                                className="w-9 h-9 shrink-0 rounded-full border border-border bg-surface/60 hover:bg-rose-soft hover:text-primary flex items-center justify-center text-text-secondary transition-colors disabled:opacity-50"
                            >
                                ✕
                            </button>
                        </div>

                        {/* Form */}
                        <form
                            onSubmit={(event) => {
                                event.preventDefault();
                                saveInternship(false);
                            }}
                            className="relative flex flex-col max-h-[calc(94vh-90px)]"
                        >
                            <div className="flex-1 overflow-y-auto px-5 sm:px-8 py-6 space-y-7">

                                {/* Basic information */}
                                <section className="space-y-4">
                                    <div>
                                        <h3 className="font-ui text-sm font-bold text-text">
                                            Basic Information
                                        </h3>

                                        <p className="font-ui text-xs text-text-muted mt-1">
                                            Introduce the opportunity to potential candidates.
                                        </p>
                                    </div>

                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                        <div className="sm:col-span-2">
                                            <FormField
                                                label="Internship Title"
                                                name="title"
                                                value={formData.title}
                                                onChange={handleFormChange}
                                                placeholder="e.g. Frontend Developer Intern"
                                                required
                                            />
                                        </div>

                                        <FormField
                                            label="Category"
                                            name="category"
                                            value={formData.category}
                                            onChange={handleFormChange}
                                            placeholder="e.g. Engineering"
                                            required
                                        />

                                        <FormField
                                            label="Work Mode"
                                            name="workMode"
                                            value={formData.workMode}
                                            onChange={handleFormChange}
                                            options={[
                                                { value: "remote", label: "Remote" },
                                                { value: "hybrid", label: "Hybrid" },
                                                { value: "onsite", label: "On-site" },
                                            ]}
                                        />
                                    </div>
                                </section>

                                <div className="h-px bg-border/70" />

                                {/* Location */}
                                <section className="space-y-4">
                                    <h3 className="font-ui text-sm font-bold text-text">
                                        Location
                                    </h3>

                                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                                        <FormField
                                            label="City"
                                            name="city"
                                            value={formData.city}
                                            onChange={handleFormChange}
                                            placeholder="e.g. Bengaluru"
                                        />

                                        <FormField
                                            label="State"
                                            name="state"
                                            value={formData.state}
                                            onChange={handleFormChange}
                                            placeholder="e.g. Karnataka"
                                        />

                                        <FormField
                                            label="Country"
                                            name="country"
                                            value={formData.country}
                                            onChange={handleFormChange}
                                            placeholder="e.g. India"
                                        />
                                    </div>
                                </section>

                                <div className="h-px bg-border/70" />

                                {/* Compensation and duration */}
                                <section className="space-y-4">
                                    <h3 className="font-ui text-sm font-bold text-text">
                                        Compensation and Duration
                                    </h3>

                                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                                        <FormField
                                            label="Stipend Amount (INR)"
                                            name="stipendAmount"
                                            value={formData.stipendAmount}
                                            onChange={handleFormChange}
                                            type="number"
                                            min="0"
                                            placeholder="15000"
                                        />

                                        <FormField
                                            label="Stipend Period"
                                            name="stipendPeriod"
                                            value={formData.stipendPeriod}
                                            onChange={handleFormChange}
                                            options={[
                                                { value: "hourly", label: "Hourly" },
                                                { value: "weekly", label: "Weekly" },
                                                { value: "monthly", label: "Monthly" },
                                                { value: "total", label: "Total" },
                                                { value: "unpaid", label: "Unpaid" },
                                                { value: "unspecified", label: "Not specified" },
                                            ]}
                                        />

                                        <FormField
                                            label="Duration Value"
                                            name="durationValue"
                                            value={formData.durationValue}
                                            onChange={handleFormChange}
                                            type="number"
                                            min="1"
                                            placeholder="3"
                                        />

                                        <FormField
                                            label="Duration Unit"
                                            name="durationUnit"
                                            value={formData.durationUnit}
                                            onChange={handleFormChange}
                                            options={[
                                                { value: "days", label: "Days" },
                                                { value: "weeks", label: "Weeks" },
                                                { value: "months", label: "Months" },
                                            ]}
                                        />

                                        <FormField
                                            label="Application Deadline"
                                            name="deadline"
                                            value={formData.deadline}
                                            onChange={handleFormChange}
                                            type="date"
                                            min={new Date().toISOString().split("T")[0]}
                                        />
                                    </div>
                                </section>

                                <div className="h-px bg-border/70" />

                                {/* Description */}
                                <section className="space-y-4">
                                    <div>
                                        <h3 className="font-ui text-sm font-bold text-text">
                                            Role Description
                                        </h3>

                                        <p className="font-ui text-xs text-text-muted mt-1">
                                            Explain the role, responsibilities and learning experience.
                                        </p>
                                    </div>

                                    <div>
                                        <label className="block font-ui text-xs font-semibold text-text-secondary mb-1.5">
                                            Internship Description *
                                        </label>

                                        <textarea
                                            required
                                            rows={5}
                                            name="description"
                                            value={formData.description}
                                            onChange={handleFormChange}
                                            placeholder="Describe the opportunity, team, responsibilities and learning experience..."
                                            className="w-full resize-y px-3.5 py-3 rounded-xl bg-white/60 dark:bg-white/5 border border-border text-sm text-text placeholder:text-text-muted outline-none focus:border-primary focus:ring-2 focus:ring-primary/10"
                                        />
                                    </div>
                                </section>

                                <div className="h-px bg-border/70" />

                                {/* Skills */}
                                <section className="space-y-4">
                                    <h3 className="font-ui text-sm font-bold text-text">
                                        Skills
                                    </h3>

                                    <FormField
                                        label="Required Skills"
                                        name="requiredSkills"
                                        value={formData.requiredSkills}
                                        onChange={handleFormChange}
                                        placeholder="JavaScript, React, Node.js"
                                    />

                                    <p className="font-ui text-[10px] text-text-muted -mt-2">
                                        Separate skills with commas.
                                    </p>

                                    <FormField
                                        label="Preferred Skills"
                                        name="preferredSkills"
                                        value={formData.preferredSkills}
                                        onChange={handleFormChange}
                                        placeholder="Docker, AWS, Git"
                                    />
                                </section>

                                <div className="h-px bg-border/70" />

                                {/* Eligibility */}
                                <section className="space-y-4">
                                    <h3 className="font-ui text-sm font-bold text-text">
                                        Eligibility
                                    </h3>

                                    <FormField
                                        label="Eligible Degrees"
                                        name="degrees"
                                        value={formData.degrees}
                                        onChange={handleFormChange}
                                        placeholder="B.Tech, BCA, MCA"
                                    />

                                    <p className="font-ui text-[10px] text-text-muted -mt-2">
                                        Separate degrees with commas.
                                    </p>

                                    <FormField
                                        label="Graduation Years"
                                        name="graduationYears"
                                        value={formData.graduationYears}
                                        onChange={handleFormChange}
                                        placeholder="2026, 2027, 2028"
                                    />

                                    <p className="font-ui text-[10px] text-text-muted -mt-2">
                                        Separate years with commas.
                                    </p>

                                    <div>
                                        <label className="block font-ui text-xs font-semibold text-text-secondary mb-1.5">
                                            Other Requirements
                                        </label>

                                        <textarea
                                            rows={3}
                                            name="otherRequirements"
                                            value={formData.otherRequirements}
                                            onChange={handleFormChange}
                                            placeholder="Mention any additional eligibility requirements..."
                                            className="w-full resize-y px-3.5 py-3 rounded-xl bg-white/60 dark:bg-white/5 border border-border text-sm text-text placeholder:text-text-muted outline-none focus:border-primary"
                                        />
                                    </div>
                                </section>

                                <div className="h-px bg-border/70" />

                                {/* Application method */}
                                <section className="space-y-4">
                                    <h3 className="font-ui text-sm font-bold text-text">
                                        Application Method
                                    </h3>

                                    <FormField
                                        label="How should students apply?"
                                        name="applicationMethod"
                                        value={formData.applicationMethod}
                                        onChange={handleFormChange}
                                        options={[
                                            {
                                                value: "internal",
                                                label: "Apply through InternCheck",
                                            },
                                            {
                                                value: "external",
                                                label: "External application link",
                                            },
                                        ]}
                                    />

                                    {formData.applicationMethod === "external" && (
                                        <FormField
                                            label="Application URL"
                                            name="applicationUrl"
                                            value={formData.applicationUrl}
                                            onChange={handleFormChange}
                                            placeholder="https://example.com/apply"
                                            required
                                        />
                                    )}
                                </section>
                            </div>

                            {/* Modal footer */}
                            <div className="px-5 sm:px-8 py-4 border-t border-border/70 bg-surface/90 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                                <p className="font-ui text-[10px] text-text-muted">
                                    {editingInternship
                                        ? "Editing an active listing will return it to draft status."
                                        : "New internships are saved as drafts first."}
                                </p>

                                <div className="flex flex-wrap items-center justify-end gap-2">
                                    <button
                                        type="button"
                                        disabled={saving}
                                        onClick={closePostModal}
                                        className="px-4 py-2.5 rounded-xl border border-border text-text-secondary font-ui text-xs font-semibold hover:bg-surface-alt disabled:opacity-50"
                                    >
                                        Cancel
                                    </button>

                                    <button
                                        type="submit"
                                        disabled={saving}
                                        className="px-4 py-2.5 rounded-xl border border-primary/20 text-primary font-ui text-xs font-bold hover:bg-rose-soft disabled:opacity-50"
                                    >
                                        {saving ? "Saving..." : "Save Draft"}
                                    </button>

                                    <button
                                        type="button"
                                        disabled={saving}
                                        onClick={() => saveInternship(true)}
                                        className="px-4 py-2.5 rounded-xl bg-primary text-white font-ui text-xs font-bold hover:opacity-90 disabled:opacity-50"
                                    >
                                        {saving ? "Submitting..." : "Save & Submit"}
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}
