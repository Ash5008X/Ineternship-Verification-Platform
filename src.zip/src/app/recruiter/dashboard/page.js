
"use client";

import { useState } from "react";
import RecruiterPageHeader from "@/components/shared/recruiter/RecruiterPageHeader";
import RecruiterSectionHeader from "@/components/shared/recruiter/RecruiterSectionHeader";

const recruiterProfile = {
    name: "Ashmit Sharma",
    greetingName: "Ashmit",
    avatarText: "AS",
    companyName: "TechNova Solutions",
};

const initialInternships = [
    {
        id: "INT-001",
        title: "Frontend Developer Intern",
        department: "Engineering",
        type: "Full-time",
        applicants: 42,
        posted: "12 Nov 2026",
        status: "Active",
    },
    {
        id: "INT-002",
        title: "Backend Developer Intern",
        department: "Engineering",
        type: "Full-time",
        applicants: 28,
        posted: "10 Nov 2026",
        status: "Pending",
    },
    {
        id: "INT-003",
        title: "UI/UX Design Intern",
        department: "Design",
        type: "Part-time",
        applicants: 16,
        posted: "08 Nov 2026",
        status: "Draft",
    },
    {
        id: "INT-004",
        title: "Data Analyst Intern",
        department: "Analytics",
        type: "Full-time",
        applicants: 31,
        posted: "05 Nov 2026",
        status: "Rejected",
    },
];

const recentApplications = [
    {
        id: 1,
        name: "Priya Sharma",
        initials: "PS",
        position: "Frontend Developer Intern",
        university: "Lovely Professional University",
        time: "2 hours ago",
        status: "New",
    },
    {
        id: 2,
        name: "Rahul Verma",
        initials: "RV",
        position: "Backend Developer Intern",
        university: "Chandigarh University",
        time: "5 hours ago",
        status: "Under Review",
    },
    {
        id: 3,
        name: "Ananya Singh",
        initials: "AS",
        position: "UI/UX Design Intern",
        university: "Delhi University",
        time: "Yesterday",
        status: "Shortlisted",
    },
];

const statusStyles = {
    Active: "bg-success/10 text-success",
    Pending: "bg-amber-500/10 text-amber-600",
    Draft: "bg-surface-alt text-text-secondary",
    Rejected: "bg-red-500/10 text-red-600",
};

const applicationStatusStyles = {
    New: "bg-primary/10 text-primary",
    "Under Review": "bg-amber-500/10 text-amber-600",
    Shortlisted: "bg-success/10 text-success",
};

function StatCard({ label, value, description, icon, accent }) {
    return (
        <div className="rounded-[var(--radius-lg)] border border-border bg-surface p-4 sm:p-5 shadow-xs">
            <div className="flex items-start justify-between gap-3">
                <div>
                    <p className="font-ui text-xs font-semibold text-text-secondary">
                        {label}
                    </p>

                    <p className="font-display text-3xl text-text tracking-tight mt-2">
                        {value}
                    </p>

                    <p className="font-ui text-[11px] text-text-muted mt-1">
                        {description}
                    </p>
                </div>

                <div className={`w-10 h-10 rounded-[var(--radius-md)] flex items-center justify-center ${accent}`}>
                    {icon}
                </div>
            </div>
        </div>
    );
}

function StatusBadge({ status }) {
    return (
        <span
            className={`inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-bold font-ui ${statusStyles[status] || "bg-surface-alt text-text-secondary"}`}
        >
            {status}
        </span>
    );
}

export default function RecruiterDashboardPage() {
    const [internships, setInternships] = useState(initialInternships);
    const [activeFilter, setActiveFilter] = useState("All");
    const [toastMessage, setToastMessage] = useState(null);

    const showToast = (message) => {
        setToastMessage(message);

        setTimeout(() => {
            setToastMessage(null);
        }, 3200);
    };

    const filteredInternships =
        activeFilter === "All"
            ? internships
            : internships.filter(
                (internship) => internship.status === activeFilter
            );

    const stats = [
        {
            label: "Total Listings",
            value: "12",
            description: "Across all departments",
            accent: "bg-primary/10 text-primary",
            icon: (
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01" />
                </svg>
            ),
        },
        {
            label: "Active Listings",
            value: "7",
            description: "Currently visible to students",
            accent: "bg-success/10 text-success",
            icon: (
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                </svg>
            ),
        },
        {
            label: "Total Applicants",
            value: "186",
            description: "Across all internship listings",
            accent: "bg-amber-500/10 text-amber-600",
            icon: (
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15 19.128a9.38 9.38 0 0 0 2.625.372A9.375 9.375 0 0 0 21 18.875M15 19.128v-.003c0-1.113-.32-2.15-.875-3.025M15 19.128v.002A9.35 9.35 0 0 1 12 21a9.35 9.35 0 0 1-2.125-1.87M15 19.128a9.35 9.35 0 0 1-6.25 0M9 19.128v-.003c0-1.113.32-2.15.875-3.025M9 19.128v.002A9.35 9.35 0 0 0 12 21M9 19.128a9.38 9.38 0 0 1-2.625.372A9.375 9.375 0 0 1 3 18.875M12 12a4.5 4.5 0 1 0 0-9 4.5 4.5 0 0 0 0 9Z" />
                </svg>
            ),
        },
        {
            label: "Pending Reviews",
            value: "3",
            description: "Listings awaiting verification",
            accent: "bg-orange-500/10 text-orange-600",
            icon: (
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6l4 2m5-2a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                </svg>
            ),
        },
    ];

    return (
        <>
            <main className="flex-1 min-w-0 py-6 px-4 sm:px-6 lg:px-8 max-w-[1600px] mx-auto w-full">

                {toastMessage && (
                    <div className="fixed bottom-5 right-5 z-50 bg-text text-background px-4 py-2.5 rounded-[var(--radius-md)] text-xs font-semibold shadow-lg flex items-center gap-2.5 border border-border">
                        <span className="w-2 h-2 rounded-full bg-success" />
                        <span>{toastMessage}</span>
                    </div>
                )}

                {/* Welcome section */}
                <section className="mb-6">
                    <RecruiterPageHeader
                        recruiter={recruiterProfile}
                        message={`Manage your opportunities at ${recruiterProfile.companyName}.`}
                    />
                </section>

                {/* Statistics */}
                <section className="mb-6">
                    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
                        {stats.map((stat) => (
                            <StatCard key={stat.label} {...stat} />
                        ))}
                    </div>
                </section>

                {/* Main dashboard grid */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">

                    {/* Left column */}
                    <div className="lg:col-span-8 xl:col-span-8 space-y-6">

                        {/* Internship listings */}
                        <section className="rounded-[var(--radius-lg)] border border-border bg-surface p-4 sm:p-5 shadow-xs">

                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-border/80">
                                <RecruiterSectionHeader
                                    title="Your internship listings"
                                    subtitle="Create, manage and monitor your opportunities."
                                    action={
                                        <button
                                            type="button"
                                            onClick={() => showToast("Create internship page will be connected next.")}
                                            className="inline-flex items-center gap-2 px-3 py-2 rounded-[var(--radius-md)] bg-primary text-white text-xs font-semibold hover:opacity-90 transition-opacity"
                                        >
                                            <span className="text-base leading-none">+</span>
                                            Create Listing
                                        </button>
                                    }
                                />
                            </div>

                            {/* Filters */}
                            <div className="flex items-center gap-1.5 flex-wrap mt-4">
                                {["All", "Active", "Pending", "Draft", "Rejected"].map((filter) => (
                                    <button
                                        key={filter}
                                        type="button"
                                        onClick={() => setActiveFilter(filter)}
                                        className={`text-xs font-semibold px-2.5 py-1 rounded-[var(--radius-sm)] transition-colors cursor-pointer select-none ${
                                            activeFilter === filter
                                                ? "bg-primary text-white"
                                                : "bg-surface-alt text-text-secondary hover:text-text border border-border"
                                        }`}
                                    >
                                        {filter}
                                    </button>
                                ))}
                            </div>

                            {/* Listing cards */}
                            <div className="mt-4 space-y-3">
                                {filteredInternships.length === 0 ? (
                                    <div className="text-center py-12">
                                        <p className="font-ui text-sm font-semibold text-text">
                                            No listings found
                                        </p>
                                        <p className="font-ui text-xs text-text-muted mt-1">
                                            Try selecting another status filter.
                                        </p>
                                    </div>
                                ) : (
                                    filteredInternships.map((internship) => (
                                        <div
                                            key={internship.id}
                                            className="rounded-[var(--radius-md)] border border-border p-4 hover:border-primary/30 transition-colors"
                                        >
                                            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                                                <div className="min-w-0">
                                                    <div className="flex flex-wrap items-center gap-2 mb-1.5">
                                                        <h3 className="font-ui text-sm font-bold text-text">
                                                            {internship.title}
                                                        </h3>
                                                        <StatusBadge status={internship.status} />
                                                    </div>

                                                    <p className="font-ui text-xs text-text-secondary">
                                                        {internship.department} · {internship.type}
                                                    </p>

                                                    <div className="flex flex-wrap items-center gap-x-4 gap-y-2 mt-3 text-[11px] text-text-muted font-ui">
                                                        <span>{internship.id}</span>
                                                        <span>{internship.applicants} applicants</span>
                                                        <span>Posted {internship.posted}</span>
                                                    </div>
                                                </div>

                                                <button
                                                    type="button"
                                                    onClick={() => showToast(`Opening ${internship.title}`)}
                                                    className="shrink-0 text-xs font-semibold text-primary hover:opacity-70"
                                                >
                                                    Manage listing →
                                                </button>
                                            </div>
                                        </div>
                                    ))
                                )}
                            </div>

                            <div className="pt-4 mt-4 border-t border-border/80 flex items-center justify-between">
                                <p className="font-ui text-[11px] text-text-muted">
                                    Showing {filteredInternships.length} of {internships.length} listings
                                </p>

                                <button
                                    type="button"
                                    onClick={() => {
                                        setActiveFilter("All");
                                        setInternships(initialInternships);
                                        showToast("Listings view reset.");
                                    }}
                                    className="font-ui text-xs font-semibold text-primary hover:opacity-70"
                                >
                                    Reset filters
                                </button>
                            </div>
                        </section>

                        {/* Recent applications */}
                        <section className="rounded-[var(--radius-lg)] border border-border bg-surface p-4 sm:p-5 shadow-xs">
                            <div className="flex items-center justify-between gap-3 pb-3 border-b border-border/80">
                                <RecruiterSectionHeader
                                    title="Recent applications"
                                    subtitle="Keep track of students applying to your listings."
                                />

                                <button
                                    type="button"
                                    onClick={() => showToast("Application management will be connected next.")}
                                    className="text-xs font-semibold text-primary shrink-0"
                                >
                                    View all →
                                </button>
                            </div>

                            <div className="divide-y divide-border">
                                {recentApplications.map((application) => (
                                    <div
                                        key={application.id}
                                        className="py-4 flex items-center gap-3"
                                    >
                                        <div className="w-9 h-9 shrink-0 rounded-full bg-rose-soft text-primary flex items-center justify-center font-ui text-xs font-bold">
                                            {application.initials}
                                        </div>

                                        <div className="flex-1 min-w-0">
                                            <p className="font-ui text-xs font-bold text-text truncate">
                                                {application.name}
                                            </p>
                                            <p className="font-ui text-[11px] text-text-secondary truncate mt-0.5">
                                                {application.position}
                                            </p>
                                            <p className="font-ui text-[10px] text-text-muted mt-1">
                                                {application.university} · {application.time}
                                            </p>
                                        </div>

                                        <div className="flex flex-col items-end gap-2 shrink-0">
                                            <span className={`px-2 py-1 rounded-full text-[10px] font-bold font-ui ${applicationStatusStyles[application.status]}`}>
                                                {application.status}
                                            </span>

                                            <button
                                                type="button"
                                                onClick={() => showToast(`Viewing ${application.name}'s application`)}
                                                className="text-[10px] font-semibold text-primary"
                                            >
                                                View
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </section>
                    </div>

                    {/* Right column */}
                    <aside className="lg:col-span-4 xl:col-span-4 space-y-4">

                        {/* Company profile */}
                        <RecruiterSectionHeader
                            title="Company profile"
                            subtitle="Your recruiter account overview."
                        />
                        <section className="rounded-[var(--radius-lg)] border border-border bg-surface p-4 sm:p-5 shadow-xs">
                            <RecruiterSectionHeader
                                title="Company profile"
                                subtitle="Your recruiter account overview."
                            />

                            <div className="mt-4 flex items-center gap-3">
                                <div className="w-11 h-11 rounded-[var(--radius-md)] bg-rose-soft text-primary flex items-center justify-center font-ui font-extrabold text-sm">
                                    TN
                                </div>

                                <div className="min-w-0">
                                    <p className="font-ui text-sm font-bold text-text">
                                        TechNova Solutions
                                    </p>
                                    <p className="font-ui text-[11px] text-text-muted mt-0.5">
                                        Technology · Software
                                    </p>
                                </div>
                            </div>

                            <div className="mt-4 pt-3 border-t border-border space-y-3">
                                <div className="flex justify-between text-xs">
                                    <span className="text-text-secondary">Verification status</span>
                                    <span className="font-semibold text-success">Verified</span>
                                </div>

                                <div className="flex justify-between text-xs">
                                    <span className="text-text-secondary">Account type</span>
                                    <span className="font-semibold text-text">Recruiter</span>
                                </div>

                                <button
                                    type="button"
                                    onClick={() => showToast("Company profile page coming soon.")}
                                    className="w-full mt-1 py-2 rounded-[var(--radius-md)] border border-border text-xs font-semibold text-text hover:bg-surface-alt transition-colors"
                                >
                                    View company profile
                                </button>
                            </div>
                        </section>

                        {/* Listing summary */}
                        <section className="rounded-[var(--radius-lg)] border border-border bg-surface p-4 sm:p-5 shadow-xs">
                            <RecruiterSectionHeader
                                title="Listing overview"
                                subtitle="Current distribution of your listings."
                            />

                            <div className="mt-4 space-y-4">
                                {[
                                    { label: "Active", count: 7, color: "bg-success" },
                                    { label: "Pending", count: 3, color: "bg-amber-500" },
                                    { label: "Draft", count: 1, color: "bg-border" },
                                    { label: "Rejected", count: 1, color: "bg-red-500" },
                                ].map((item) => (
                                    <div key={item.label}>
                                        <div className="flex items-center justify-between mb-1.5">
                                            <span className="font-ui text-xs text-text-secondary">
                                                {item.label}
                                            </span>
                                            <span className="font-ui text-xs font-bold text-text">
                                                {item.count}
                                            </span>
                                        </div>

                                        <div className="h-1.5 rounded-full bg-surface-alt overflow-hidden">
                                            <div
                                                className={`h-full rounded-full ${item.color}`}
                                                style={{ width: `${(item.count / 12) * 100}%` }}
                                            />
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </section>

                        {/* Quick actions */}
                        <section className="rounded-[var(--radius-lg)] border border-border bg-surface p-4 sm:p-5 shadow-xs">
                            <RecruiterSectionHeader
                                title="Quick actions"
                                subtitle="Common recruiter tasks."
                            />

                            <div className="mt-3 space-y-2">
                                {[
                                    {
                                        label: "Create internship listing",
                                        description: "Publish a new opportunity",
                                    },
                                    {
                                        label: "Review applications",
                                        description: "Check incoming student applications",
                                    },
                                    {
                                        label: "Edit company profile",
                                        description: "Update your organization details",
                                    },
                                ].map((action) => (
                                    <button
                                        key={action.label}
                                        type="button"
                                        onClick={() => showToast(`${action.label} will be available soon.`)}
                                        className="w-full text-left rounded-[var(--radius-md)] p-3 border border-border hover:bg-surface-alt transition-colors"
                                    >
                                        <p className="font-ui text-xs font-bold text-text">
                                            {action.label}
                                        </p>
                                        <p className="font-ui text-[11px] text-text-muted mt-0.5">
                                            {action.description}
                                        </p>
                                    </button>
                                ))}
                            </div>
                        </section>
                    </aside>
                </div>
            </main>
        </>
    );
}
